# EmojiPlus 
![Banner](https://github.com/charityrolfson433/EmojiPlus/raw/main/Banner.jpg)

# Credits
[**NotoEmojiPlus_OMF**](https://gitlab.com/MrCarb0n/NotoEmojiPlus_OMF) | [**Noto Emoji**](https://github.com/googlefonts/noto-emoji)

